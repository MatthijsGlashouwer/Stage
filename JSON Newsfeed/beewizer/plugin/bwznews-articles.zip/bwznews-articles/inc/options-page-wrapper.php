<div class="wrap">

	<div id="icon-options-general" class="icon32"></div>
	<h1>BeeWizer Nieuwsfeed</h1>

	<div id="poststuff">

		<div id="post-body" class="metabox-holder columns-2">

			<!-- main content -->
			<div id="post-body-content">

				<div class="meta-box-sortables ui-sortable">




					<!-- .postbox -->
					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span>Overzicht</span>
						</h2>

						<div class="inside">
						<p>Overzicht Nieuws berichten</p>	

							<ul class="bwznews-articles">
							<?php
								
							if (! empty($bwznews_results)) {
								
								foreach($bwznews_results as $result){

									echo '<h1>' . ($result->header) . '</h1><br />';
									echo '<h2>' . ($result->author) . '</h2><br />';
									//echo ('<img src="'.$result->images[0]->source.'">');
									//echo '<h4>' . ($result->content) . '</h4>';
								}
							}

								
								

								if (!get_page_by_title($result->header,OBJECT, 'post')) :

									foreach ($bwznews_results as $result){
										
									

										$new_post = array(

											'post_title' => $result->header, 
											'post_content' => $result->content,
											'post_status'   => 'publish',
											'post_author'   => 3,
											'post_date' =>  date('Y-m-d H:i:s',$result->publicationDate),
											'post_category' => array( 168 ),
											'post_type' => 'post',
											//'comment_status' => 'closed'

											
										);

										$post_id = wp_insert_post( $new_post );
										

										$image_url = $result->images[0]->source;
										$image_name = $result->images[0]->filename;
										$upload_dir = wp_upload_dir();
										$image_data = file_get_contents($image_url);
										$unique_file_name = wp_unique_filename($upload_dir['path'],$image_name);
										$filename = basename($unique_file_name);
										
										// Check folder permission and define file location
										if( wp_mkdir_p( $upload_dir['path'] ) ) {
										    $file = $upload_dir['path'] . '/' . $filename;
										} else {
										    $file = $upload_dir['basedir'] . '/' . $filename;
										}

										// Create the image  file on the server
										file_put_contents( $file, $image_data );

										// Check image file type
										$wp_filetype = wp_check_filetype( $filename, null );

										// Set attachment data
										$attachment = array(
										    'post_mime_type' => $wp_filetype['type'],
										    'post_title'     => sanitize_file_name( $filename ),
										    'post_content'   => '',
										    'post_status'    => 'inherit'
										);

										// Create the attachment
										$attach_id = wp_insert_attachment( $attachment, $file, $post_id );

										// Include image.php
										require_once(ABSPATH . 'wp-admin/includes/image.php');

										// Define attachment metadata
										$attach_data = wp_generate_attachment_metadata( $attach_id, $file );

										// Assign metadata to attachment
										wp_update_attachment_metadata( $attach_id, $attach_data );

										// And finally assign featured image to post
										set_post_thumbnail( $post_id, $attach_id );

										$my_cat = array(
											'cat_name' => 'Marne',
											'category_description' => 'Marne',
											'category_nicename' => 'categorie'
											
											);

										$test = array(
											'cat_name' => 'Bogerman',
											'category_description' => 'Bogerman',
											'category_nicename' => 'categorie'
										);

										$my_cat_id = wp_insert_category($my_cat);
										$test_id = wp_insert_category($test);

									}

								endif;
								
							 ?>
							 </ul>
						</div>

					</div>



				</div>
				<!-- .meta-box-sortables .ui-sortable -->

			</div>
			<!-- post-body-content -->


			<!-- #postbox-container-1 .postbox-container -->

		</div>
		<!-- #post-body .metabox-holder .columns-2 -->

		<br class="clear">
	</div>
	<!-- #poststuff -->

</div> <!-- .wrap -->