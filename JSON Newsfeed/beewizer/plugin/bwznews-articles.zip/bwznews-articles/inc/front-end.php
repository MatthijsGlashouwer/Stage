<?php 

	echo $before_widget;
	echo $before_title . $title . $after_title;
?>
<ul class="bwznews-articles frontend">


	<li class="bwznews-articles">

		<div class="bwznews-articles-info">
                                    <?php if ( has_post_thumbnail() && $image ): ?>
                                        <?php the_post_thumbnail( array(100,100) ); ?>
                                    <?php endif ?>			
		</div>

	</li>
	
	<?php endfor; ?>

</ul>




<?php
	echo $after_widget;
?>