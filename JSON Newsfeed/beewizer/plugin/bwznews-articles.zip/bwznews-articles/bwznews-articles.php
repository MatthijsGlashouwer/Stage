<?php

/*
 *	Plugin Name: BeeWizer Nieuws overzicht
 *	Plugin URI: zwf-ontwerp.nl
 *	Description: Widget & Shortcode voor het maken van een newsfeed
 *	Version: 1.0
 *	Author: Matthijs Glashouwer
 *	Author URI: matthijs@zwf-ontwerp.nl
 *	License: GPL2
 *
*/

$plugin_url = WP_PLUGIN_URL . '/bwznews-articles';
$options = array();

function bwznews_articles_menu(){

	add_options_page(
		'BeeWizer News Overzicht plugin',
		'BWZNews',
		'manage_options',
		'bwznews-articles',
		'bwznews_articles_options_page'
	);

}

add_action('admin_menu', 'bwznews_articles_menu');




add_action( 'wp_enqueue_scripts', 'ajax_test_enqueue_scripts' );
function ajax_test_enqueue_scripts() {
	wp_enqueue_script( 'test', plugins_url( '/inc/test.js', __FILE__ ), array('jquery'), '1.0', true );
}



function bwznews_articles_options_page() {

	if (!current_user_can('manage_options' )){
		wp_die('Niet genoeg rechten om deze pagina te bekijken');
	}

	global $plugin_url;
	global $options;


	if (isset($_POST['bwznews_form_submitted'])){
		$hidden_field = esc_html( $_POST['bwznews_form_submitted']);

		if($hidden_field == 'Y'){

			$bwznews_results = bwznews_articles_get_results($bwznews_search, $bwznews_category);
			$options['bwznews_results'] = $bwznews_results;
		}
	}

	$options = get_option('bwznews_articles');

	if ($options != ''){
		$bwznews_results = $options['bwznews_results'];
	}

	require('inc/options-page-wrapper.php');

}





function bwznews_articles_get_results(){
			
		$json_feed_url = 'http://cvo.education.misp.nl/republish';

		$json_feed = wp_remote_get($json_feed_url);

		if( is_wp_error( $json_feed)) {
			return false;
		}

		$bwznews_results = json_decode($json_feed['body']);

		return $bwznews_results;
}

function bwznews_articles_backend_styles(){

	wp_enqueue_style('bwznews_articles_backend_css', plugins_url('bwznews-articles/bwznews-articles.css') );
}

add_action('admin_head', 'bwznews_articles_backend_styles');



 ?>







