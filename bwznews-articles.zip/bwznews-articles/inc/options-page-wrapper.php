<div class="wrap">

	<div id="icon-options-general" class="icon32"></div>
	<h1>BeeWizer Nieuwsfeed</h1>

	<div id="poststuff">

		<div id="post-body" class="metabox-holder columns-2">

			<!-- main content -->
			<div id="post-body-content">

				<div class="meta-box-sortables ui-sortable">

					<?php if (!isset($bwznews_search) || $bwznews_search == ''):?>

					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span>Invullen</span>
						</h2>

						<div class="inside">
						<form method ="post" action="">


						<input type="hidden" name="bwznews_form_submitted" value ="Y">

						<table class="form-table">
							<tr valign="top">
								<td scope="row"><label for="tablecell">Zoeken</label></td>
								<td><input name="bwznews_search" id="bwznews_search" type="text" value="" class="regular-text" /></td>
							</tr>
							<tr valign="top">
								<td scope="row"><label for="tablecell">Category</label></td>
								<td><input name="bwznews_category" id="bwznews_category" type="text" value="" class="regular-text" /></td>
							</tr>
						</table>
							<p>
								<input class="button-primary" type="submit" name="bwz_form_submit" value="Opslaan" />
							</p>
						</form>
						</div>
						<!-- .inside -->

					</div>

				<?php else: ?>
					<!-- .postbox -->
					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span>Overzicht</span>
						</h2>

						<div class="inside">
						<p>Overzicht Nieuws berichten</p>	

							<ul class="bwznews-articles">

							<?php for( $i = 0; $i <= 10; $i++):?>
							<li>
								<ul>
									<li>
										<img width="120px" src="<?php echo $bwznews_results->{'59c3c8464f978d44b800002e'}->{'images'}[0]->{'source'}; ?>">
									</li>

									<li class="bwznews-articles-name">
										
											<?php echo $bwznews_results->{'59c3c8464f978d44b800002e'}->{'header'}; ?>
										
									</li>

									<li class="bwznews-articles-paragraph">
										<p><?php echo $bwznews_results->{'59c3c8464f978d44b800002e'}->{'preview'}; ?></p>
									</li>
								</ul>
							</li>
							<?php endfor; ?>
						</ul>


						</div>
						<!-- .inside -->

					</div>					
				    <?php endif; ?>

					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span>JSON FEED</span></h2>

						<div class="inside">
							<p>
								<?php echo $bwznews_results->{'59c3c8464f978d44b800002e'}->{'header'}; ?>
							</p>
							
							<p>
								<?php echo $bwznews_results->{'59c3c8464f978d44b800002e'}->{'images'}[0]->{'source'}; ?>
							</p>							


							<p>
								<?php echo $bwznews_results->{'59c3c8464f978d44b800002e'}->{'preview'}; ?>
							</p>

							<p>
								<?php echo $bwznews_results->{'59c3c8464f978d44b800002e'}->{'author'}; ?>	
							</p>
							
							<pre><code><?php var_dump($bwznews_results); ?></code></pre>											
						</div>
						<!-- .inside -->

					</div>

				</div>
				<!-- .meta-box-sortables .ui-sortable -->

			</div>
			<!-- post-body-content -->

			<!-- sidebar -->
			<div id="postbox-container-1" class="postbox-container">

				<div class="meta-box-sortables">

					<?php if (isset($bwznews_search) && $bwznews_search != ''):?>
					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span>Instellingen</span></h2>

						<div class="inside">
							<form method ="post" action="">

							<input type="hidden" name="bwznews_form_submitted" value ="Y">
								<p>
									<input name="bwznews_search" id="bwznews_search" type="text" value="<?php echo $bwznews_search; ?>" class="all-options" />
									<input name="bwznews_category" id="bwznews_category" type="text" value="<?php echo $bwznews_category; ?>" class="all-options" />
								</p>
								<p>
									<input class="button-primary" type="submit" name="bwz_form_submit" value="Updaten" />
								</p>
							</form>														
						</div>
						<!-- .inside -->

					</div>
					<!-- .postbox -->
				<?php endif; ?>




				</div>
				<!-- .meta-box-sortables -->

			</div>
			<!-- #postbox-container-1 .postbox-container -->

		</div>
		<!-- #post-body .metabox-holder .columns-2 -->

		<br class="clear">
	</div>
	<!-- #poststuff -->

</div> <!-- .wrap -->