<div class="wrap">

	<div id="icon-options-general" class="icon32"></div>
	<h1>BeeWizer Nieuwsfeed</h1>

	<div id="poststuff">

		<div id="post-body" class="metabox-holder columns-2">

			<!-- main content -->
			<div id="post-body-content">

				<div class="meta-box-sortables ui-sortable">

					<?php if (!isset($bwznews_search) || $bwznews_search == ''):?>

					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span>Invullen</span>
						</h2>

						<div class="inside">
						<form method ="post" action="">


						<input type="hidden" name="bwznews_form_submitted" value ="Y">

						<table class="form-table">
							<tr valign="top">
								<td scope="row"><label for="tablecell">Zoeken</label></td>
								<td><input name="bwznews_search" id="bwznews_search" type="text" value="" class="regular-text" /></td>
							</tr>
							<tr valign="top">
								<td scope="row"><label for="tablecell">Category</label></td>
								<td><input name="bwznews_category" id="bwznews_category" type="text" value="" class="regular-text" /></td>
							</tr>
						</table>
							<p>
								<input class="button-primary" type="submit" name="bwz_form_submit" value="Opslaan" />
							</p>
						</form>
						</div>
						<!-- .inside -->

					</div>

				<?php else: ?>
					<!-- .postbox -->
					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span>Overzicht</span>
						</h2>

						<div class="inside">
						<p>Overzicht Nieuws berichten</p>	

							<ul class="bwznews-articles">
							<?php
								
								foreach($bwznews_results as $result){

									echo '<h1>' . ($result->header) . '</h1><br />';
									echo '<h2>' . ($result->author) . '</h2><br />';
									echo ('<img src="'.$result->images[0]->source.'">');
									echo '<h4>' . ($result->content) . '</h4>';
								}
								

								/*foreach ($bwznews_results as $result){
									$new_post = array(

										'post_title' => $result->header, 
										'post_status'   => 'publish',
										'post_content' => $result->content

								);

									$post_id = wp_insert_post( $new_post, $wp_error );

									return $bwznews_results;
								}*/
							 ?>
							 </ul>

						</div>

					</div>

				    <?php endif; ?>

					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span>JSON FEED</span></h2>

						<div class="inside">
						<!-- Uncomment deze lijn om een var dump weer te geven met de results -->
						<pre><code><?php var_dump($bwznews_results); ?></code></pre>	 
									
						</div>
						<!-- .inside -->

					</div>

				</div>
				<!-- .meta-box-sortables .ui-sortable -->

			</div>
			<!-- post-body-content -->

			<!-- sidebar -->
			<div id="postbox-container-1" class="postbox-container">

				<div class="meta-box-sortables">

					<?php if (isset($bwznews_search) && $bwznews_search != ''):?>
					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span>Instellingen</span></h2>

						<div class="inside">
							<form method ="post" action="">

							<input type="hidden" name="bwznews_form_submitted" value ="Y">
								<p>
									<input name="bwznews_search" id="bwznews_search" type="text" value="<?php echo $bwznews_search; ?>" class="all-options" />
									<input name="bwznews_category" id="bwznews_category" type="text" value="<?php echo $bwznews_category; ?>" class="all-options" />
								</p>
								<p>
									<input class="button-primary" type="submit" name="bwz_form_submit" value="Updaten" />
								</p>
							</form>														
						</div>
						<!-- .inside -->

					</div>
					<!-- .postbox -->
				<?php endif; ?>




				</div>
				<!-- .meta-box-sortables -->

			</div>
			<!-- #postbox-container-1 .postbox-container -->

		</div>
		<!-- #post-body .metabox-holder .columns-2 -->

		<br class="clear">
	</div>
	<!-- #poststuff -->

</div> <!-- .wrap -->