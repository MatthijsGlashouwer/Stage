<div class="wrap">

	<div id="icon-options-general" class="icon32"></div>
	<h1>BeeWizer Nieuwsfeed</h1>

	<div id="poststuff">

		<div id="post-body" class="metabox-holder columns-2">

			<!-- main content -->
			<div id="post-body-content">

				<div class="meta-box-sortables ui-sortable">

					<?php if (!isset($bwznews_search) || $bwznews_search == ''):?>

					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span>Invullen</span>
						</h2>

						<div class="inside">
						<form method ="post" action="">


						<input type="hidden" name="bwznews_form_submitted" value ="Y">

						<table class="form-table">
							<tr valign="top">
								<td scope="row"><label for="tablecell">Zoeken</label></td>
								<td><input name="bwznews_search" id="bwznews_search" type="text" value="" class="regular-text" /></td>
							</tr>
							<tr valign="top">
								<td scope="row"><label for="tablecell">Category</label></td>
								<td><input name="bwznews_category" id="bwznews_category" type="text" value="" class="regular-text" /></td>
							</tr>
						</table>
							<p>
								<input class="button-primary" type="submit" name="bwz_form_submit" value="Opslaan" />
							</p>
						</form>
						</div>
						<!-- .inside -->

					</div>

				<?php else: ?>
					<!-- .postbox -->
					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span>Overzicht</span>
						</h2>

						<div class="inside">
						<p>Overzicht Nieuws berichten</p>	

							<ul class="bwznews-articles">
							<?php
								
								foreach($bwznews_results as $result){

									echo '<h1>' . ($result->header) . '</h1><br />';
									echo '<h2>' . ($result->author) . '</h2><br />';
									echo ('<img src="'.$result->images[0]->source.'">');
									echo '<h4>' . ($result->content) . '</h4>';
								}
								

								if (!get_page_by_title($result->header,OBJECT, 'post')) :

									foreach ($bwznews_results as $result){
										
									

										$new_post = array(

											'post_title' => $result->header, 
											'post_content' => $result->content,
											'post_status'   => 'publish',
											'post_author'   => 3,
											'post_date' =>  date('Y-m-d H:i:s',$result->publicationDate),
											'post_category' => array( 27 ),
											'post_type' => 'post',
											//'comment_status' => 'closed'

											
										);

										$post_id = wp_insert_post( $new_post );
										

										$image_url = $result->images[0]->source;
										$image_name = $result->images[0]->filename;
										$upload_dir = wp_upload_dir();
										$image_data = file_get_contents($image_url);
										$unique_file_name = wp_unique_filename($upload_dir['path'],$image_name);
										$filename = basename($unique_file_name);
										
										// Check folder permission and define file location
										if( wp_mkdir_p( $upload_dir['path'] ) ) {
										    $file = $upload_dir['path'] . '/' . $filename;
										} else {
										    $file = $upload_dir['basedir'] . '/' . $filename;
										}

										// Create the image  file on the server
										file_put_contents( $file, $image_data );

										// Check image file type
										$wp_filetype = wp_check_filetype( $filename, null );

										// Set attachment data
										$attachment = array(
										    'post_mime_type' => $wp_filetype['type'],
										    'post_title'     => sanitize_file_name( $filename ),
										    'post_content'   => '',
										    'post_status'    => 'inherit'
										);

										// Create the attachment
										$attach_id = wp_insert_attachment( $attachment, $file, $post_id );

										// Include image.php
										require_once(ABSPATH . 'wp-admin/includes/image.php');

										// Define attachment metadata
										$attach_data = wp_generate_attachment_metadata( $attach_id, $file );

										// Assign metadata to attachment
										wp_update_attachment_metadata( $attach_id, $attach_data );

										// And finally assign featured image to post
										set_post_thumbnail( $post_id, $attach_id );

										
									}

								endif;
								
							 ?>
							 </ul>

						</div>

					</div>

				    <?php endif; ?>

					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span>JSON FEED</span></h2>

						<div class="inside">
						<!-- Uncomment deze lijn om een var dump weer te geven met de results -->
						<pre><code><?php //var_dump($bwznews_results); ?></code></pre>	 
									
						</div>
						<!-- .inside -->

					</div>

				</div>
				<!-- .meta-box-sortables .ui-sortable -->

			</div>
			<!-- post-body-content -->

			<!-- sidebar -->
			<div id="postbox-container-1" class="postbox-container">

				<div class="meta-box-sortables">

					<?php if (isset($bwznews_search) && $bwznews_search != ''):?>
					<div class="postbox">

						<div class="handlediv" title="Click to toggle"><br></div>
						<!-- Toggle -->

						<h2 class="hndle"><span>Instellingen</span></h2>

						<div class="inside">
							<form method ="post" action="">

							<input type="hidden" name="bwznews_form_submitted" value ="Y">
								<p>
									<input name="bwznews_search" id="bwznews_search" type="text" value="<?php echo $bwznews_search; ?>" class="all-options" />
									<input name="bwznews_category" id="bwznews_category" type="text" value="<?php echo $bwznews_category; ?>" class="all-options" />
								</p>
								<p>
									<input class="button-primary" type="submit" name="bwz_form_submit" value="Updaten" />
								</p>
							</form>														
						</div>
						<!-- .inside -->

					</div>
					<!-- .postbox -->
				<?php endif; ?>




				</div>
				<!-- .meta-box-sortables -->

			</div>
			<!-- #postbox-container-1 .postbox-container -->

		</div>
		<!-- #post-body .metabox-holder .columns-2 -->

		<br class="clear">
	</div>
	<!-- #poststuff -->

</div> <!-- .wrap -->