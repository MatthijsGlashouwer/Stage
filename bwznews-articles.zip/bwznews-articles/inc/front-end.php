<?php 

	echo $before_widget;
	echo $before_title . $title . $after_title;
?>
<ul class="bwznews-articles frontend">

	<?php

		$total_articles = count( $bwznews_results as $results);

		for( $i = $total_articles - 1; $i >= $total_articles - $num_articles; $i-- ): 

	;?>

	<li class="bwznews-articles">

		<div class="bwznews-articles-info">
			<?php if( $display_image == '1'): ?>

				<?php if( count($bwznews_results->{'59c3c8464f978d44b800002e'}->{'images'}[0]->{'source'}) > 0): ?>

				<img width="120px" src="<?php echo $bwznews_results->{'59c3c8464f978d44b800002e'}->{'images'}[0]->{'source'}; ?>">

				<?php endif; ?>
			<?php endif; ?>

			<p class="bwznews-articles-name">
				<a href="<?php echo $bwznews_results->{'59c3c8464f978d44b800002e'}->{'header'}; ?>">
					<?php echo $bwznews_results->{'59c3c8464f978d44b800002e'}->{'header'}; ?>
				</a>
			</p>

			<p>
				<?php echo $bwznews_results->{'59c3c8464f978d44b800002e'}->{'preview'}; ?>
			</p>
			
		</div>

	</li>
	
	<?php endfor; ?>

</ul>




<?php
	echo $after_widget;
?>