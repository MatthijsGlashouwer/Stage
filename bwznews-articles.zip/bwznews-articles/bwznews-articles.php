<?php

/*
 *	Plugin Name: BeeWizer Niews overzicht
 *	Plugin URI: zwf-ontwerp.nl
 *	Description: Widget & Shortcode voor het maken van een newsfeed
 *	Version: 1.0
 *	Author: Matthijs Glashouwer
 *	Author URI: matthijs@zwf-ontwerp.nl
 *	License: GPL2
 *
*/

$plugin_url = WP_PLUGIN_URL . '/bwznews-articles';
$options = array();

function bwznews_articles_menu(){

	add_options_page(
		'BeeWizer News Overzicht plugin',
		'BWZNews',
		'manage_options',
		'bwznews-articles',
		'bwznews_articles_options_page'
	);

}

add_action('admin_menu', 'bwznews_articles_menu');


function bwznews_articles_options_page() {

	if (!current_user_can('manage_options' )){
		wp_die('Niet genoeg rechten om deze pagina te bekijken');
	}

	global $plugin_url;
	global $options;


	if (isset($_POST['bwznews_form_submitted'])){
		$hidden_field = esc_html( $_POST['bwznews_form_submitted']);

		if($hidden_field == 'Y'){
			$bwznews_search = esc_html($_POST['bwznews_search']);
			$bwznews_category = esc_html($_POST['bwznews_category']);


			$bwznews_results = bwznews_articles_get_results($bwznews_search, $bwznews_category);

			$options['bwznews_search'] = $bwznews_search;
			$options['bwznews_category'] = $bwznews_category;
			$options['last_updated'] = time();

			$options['bwznews_results'] = $bwznews_results;

			update_option('bwznews_articles', $options);
		}
	}

	$options = get_option('bwznews_articles');

	if ($options != ''){
		$bwznews_search = $options['bwznews_search'];
		$bwznews_category = $options['bwznews_category'];
		$bwznews_results = $options['bwznews_results'];
	}

	require('inc/options-page-wrapper.php');

}

class BeeWizer extends WP_Widget {

	function __construct() {
		
		parent::__construct( false, 'BeeWizer Nieuwsfeed' );
	}

	function widget( $args, $instance ) {
		
		extract($args);
		$title = apply_filters('widget_title', $instance['title']);
		$num_articles = $instance['num_articles'];
		$display_image = $instance['display_image'];

		$options = get_option('bwznews_articles');
		$bwznews_results = $options['bwznews_results'];

		require ('inc/front-end.php');
	}

	function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title'] = strip_tags($new_instance['title']);
		$instance['display_image'] = strip_tags($new_instance['display_image']);
		$instance['num_articles'] = strip_tags($new_instance['num_articles']);
		
		return $new_instance;
	}

	function form( $instance ) {
		$title = esc_attr($instance['title']);
		$display_image = esc_attr($instance['display_image']);
		$num_articles = esc_attr($instance['num_articles']);

		$options = get_option('bwznews_articles');
		$bwznews_results = $options['bwznews_results'];

		require ('inc/widget-fields.php');

	}
}
add_action( 'widgets_init', 'bwznews_articles_register_widgets' );

function bwznews_articles_register_widgets() {
	register_widget( 'BeeWizer' );
}




function bwznews_articles_get_results(){
			
		$json_feed_url = 'http://cvo.education.misp.nl/republish';

		$json_feed = wp_remote_get($json_feed_url);

		$bwznews_results = json_decode($json_feed['body']);

		return $bwznews_results;
}

function bwznews_articles_backend_styles(){

	wp_enqueue_style('bwznews_articles_backend_css', plugins_url('bwznews-articles/bwznews-articles.css') );
}

add_action('admin_head', 'bwznews_articles_backend_styles');



 ?>







